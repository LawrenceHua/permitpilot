var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/analyze/route.js")
R.c("server/chunks/[externals]_next_dist_b89b5a39._.js")
R.c("server/chunks/[root-of-the-server]__8f4e09de._.js")
R.c("server/chunks/e0ef2_next_dist_esm_build_templates_app-route_506f82ac.js")
R.c("server/chunks/7e8c9_contract-analyzer__next-internal_server_app_api_analyze_route_actions_58e4c15e.js")
R.m(39945)
module.exports=R.m(39945).exports
