1:"$Sreact.fragment"
2:I[45613,["/_next/static/chunks/444a836de069db2b.js"],"ViewportBoundary"]
3:I[45613,["/_next/static/chunks/444a836de069db2b.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[96760,["/_next/static/chunks/444a836de069db2b.js"],"IconMark"]
0:{"buildId":"2s31FkyVuWLXp642R_B1V","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
