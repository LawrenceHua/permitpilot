module.exports=[47297,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},59860,a=>{"use strict";let b={src:a.i(47297).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=workspace_huadini-products_contract-analyzer_app_ce9c5d8b._.js.map